import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

abstract class QuizGame {
    abstract void startGame();
    abstract void askQuestion();
    abstract void evaluateAnswer(String answer);
}

interface QuizGameListener {
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}

class QuizGameServer extends QuizGame {
    private List<String> questions;
    private List<QuizGameListener> listeners;

    public QuizGameServer() {
        questions = new ArrayList<>();
        listeners = new ArrayList<>();
        // Add your predefined questions here
        questions.add("What is the capital of France?");
        questions.add("Who is the author of 'To Kill a Mockingbird'?");
        questions.add("What is the chemical symbol for gold?");
    }

    public void addListener(QuizGameListener listener) {
        listeners.add(listener);
    }

    @Override
    void startGame() {
        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked("Welcome to the Quiz Game!");
        }

        int totalRounds = 3; // Number of rounds in the game

        for (int round = 1; round <= totalRounds; round++) {
            askQuestion();
        }
    }

    @Override
    void askQuestion() {
        Random random = new Random();
        int questionIndex = random.nextInt(questions.size());
        String question = questions.get(questionIndex);

        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked(question);
        }
    }

    @Override
    void evaluateAnswer(String answer) {
        boolean isCorrect = false; // Replace with your answer evaluation logic

        for (QuizGameListener listener : listeners) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }
}

class QuizGameClient extends QuizGame implements QuizGameListener {
    private QuizGameServer server;
    private Scanner scanner;

    public QuizGameClient() {
        scanner = new Scanner(System.in);
    }

    @Override
    void startGame() {
        server = new QuizGameServer();
        server.addListener(this);
        server.startGame();
    }

    @Override
    void askQuestion() {
        // Not used in the client
    }

    @Override
    void evaluateAnswer(String answer) {
        // Not used in the client
    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);
        String answer = scanner.nextLine();
        server.evaluateAnswer(answer);
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("Your answer is incorrect!");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        QuizGameClient client = new QuizGameClient();
        client.startGame();
    }
}
