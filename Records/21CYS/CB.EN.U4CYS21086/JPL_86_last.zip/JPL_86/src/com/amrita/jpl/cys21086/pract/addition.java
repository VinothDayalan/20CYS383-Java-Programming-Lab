package com.amrita.jpl.cys21086.pract;

import java.util.*;
/**
 * @Author VINOTH KUMAR D
 */
public class addition {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Value of 1st Number : ");
        int value1=sc.nextInt();
        System.out.println("Enter the Value of 2nd Number : ");
        int value2=sc.nextInt();
        int sum=value1+value2;
        System.out.println("Addition of Given Two Numbers is "+sum);
    }
}
