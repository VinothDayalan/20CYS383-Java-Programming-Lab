package com.amrita.jpl.cys21086.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BlockchainInfoApiCaller extends JFrame implements ActionListener {

    private JTextField searchField;
    private JTextArea resultArea;

    public BlockchainInfoApiCaller() {
        super("NFT OSINT");

        // Create and configure components
        JLabel searchLabel = new JLabel("Search:");
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(this);
        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);

        // Create layout and add components
        JPanel contentPane = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(searchLabel);
        inputPanel.add(searchField);
        inputPanel.add(searchButton);
        contentPane.add(inputPanel, BorderLayout.NORTH);
        contentPane.add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // Configure JFrame
        setContentPane(contentPane);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BlockchainInfoApiCaller app = new BlockchainInfoApiCaller();
            app.setVisible(true);
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            String search = searchField.getText().trim();
            if (!search.isEmpty()) {
                performApiCall(search);
            }
        }
    }

    private void performApiCall(String search) {
        String url;
        if (search.startsWith("1") || search.startsWith("3")) {
            url = "https://blockchain.info/rawaddr/" + search;
        } else if (search.startsWith("bc1")) {
            url = "https://blockchain.info/rawaddr/" + search;
        } else if (search.startsWith("L")) {
            resultArea.setText("Litecoin (LTC)");
            return;
        } else if (search.startsWith("0x")) {
            resultArea.setText("Ethereum (ETH)");
            return;
        } else if (search.startsWith("X") || search.startsWith("r")) {
            resultArea.setText("Ripple (XRP)");
            return;
        } else if (search.startsWith("t1") || search.startsWith("tb1")) {
            resultArea.setText("Bitcoin Testnet");
            return;
        } else {
            resultArea.setText("Invalid search input");
            return;
        }

        try {
            URL apiURL = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiURL.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Print the response
                resultArea.setText(response.toString());
            } else {
                resultArea.setText("Failed to fetch data. Response code: " + responseCode);
            }
        } catch (IOException ex) {
            resultArea.setText("Error occurred: " + ex.getMessage());
        }
    }
}
