package com.amrita.jpl.cys21086.pract;
public class FlagPattern {
    public static void main(String[] args) {
        int rows = 10; // Number of rows in the flag
        int columns = 20; // Number of columns in the flag

        // Outer loop for rows
        for (int i = 0; i < rows; i++) {
            // Inner loop for columns
            for (int j = 0; j < columns; j++) {
                // Print different characters based on the pattern
                if (i < rows / 2) {
                    // Upper part of the flag
                    if (j < columns / 2)
                        System.out.print("* ");
                    else
                        System.out.print("- ");
                } else {
                    // Lower part of the flag
                    if (j < columns / 2)
                        System.out.print("- ");
                    else
                        System.out.print("* ");
                }
            }
            System.out.println(); // Move to the next line after each row
        }
    }
}
