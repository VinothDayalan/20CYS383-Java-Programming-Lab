package com.amrita.jpl.cys21086.pract.gui;

import javax.swing.*;
import java.awt.*;

//This is a simple form layout
/**
 * This is a simple form layout
 * @author Vinoth Kumar D
 * @version 1.0
 * @param args
 */

public class FormLayoutAnokha extends JFrame {
    /**
     * @param args
     * @return void
     * @exception Exception
     * @see Exception
     * 
     */
    public FormLayoutAnokha() {
        // Set the title and close operation

        setTitle("Anokha Form");
        setSize(40, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Labels 
        JLabel label1 = new JLabel(" Full Name");
        JLabel label2 = new JLabel("Roll Number");
        JLabel label3 = new JLabel("College Mail id");
        JLabel label4 = new JLabel("Deperatment");

        // Buttons
        JButton button1 = new JButton("Vinoth Kumar D");
        JButton button2 = new JButton("CB.EN.U4CYS21086");
        JButton button3 = new 
JButton("cb.en.u4cys21086@cb.students.amrita.edu");
        JButton button4 = new JButton("CYS");
        JButton button5 = new JButton("Submit");
        // Add components to the content pane

        add(label1);
        add(button1);
        add(label2);
        add(button2);
        add(label3);
        add(button3);
        add(label4);
        add(button4);
        add(button5);

        // Make the window visible
        setVisible(true);
    }
    public static void main(String[] args) {
        new FormLayoutAnokha();
    }
}

