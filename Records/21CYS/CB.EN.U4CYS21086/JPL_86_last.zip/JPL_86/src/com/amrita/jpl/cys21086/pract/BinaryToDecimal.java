package com.amrita.jpl.cys21086.pract;

public class BinaryToDecimal {
    public static void main(String[] args) {
        String binaryNumber = "101010"; // Binary number to convert

        // Convert binary to decimal
        int decimalNumber = Integer.parseInt(binaryNumber, 2);
        String hexNumber = Integer.toHexString(decimalNumber);
        System.out.println("Binary Number: " + binaryNumber);
        System.out.println("Decimal Number: " + decimalNumber);
        System.out.println("Hexadecimal Number: " + hexNumber);
    }
}
