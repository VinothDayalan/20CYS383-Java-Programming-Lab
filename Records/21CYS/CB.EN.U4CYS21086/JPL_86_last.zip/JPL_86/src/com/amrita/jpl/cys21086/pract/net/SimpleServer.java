package com.amrita.jpl.cys21086.pract.net;

import java.io.*;
import java.net.*;

/**
 * The SimpleServer class represents a simple server program.
 * It listens for incoming connections on a specified port and receives
 * messages from clients.
 * This class demonstrates basic network programming using sockets.
 *
 * Usage:
 * - Run the SimpleServer program.
 * - Connect to the server using a client program and send a message.
 * - The server receives the message and prints it to the console.
 * - The server then closes the connection.
 * - The chat bot runs until the message from either side is "exit".
 *
 * Note: Ensure that the port number used in the server code matches the client's connection port.
 * Also, make sure the client program is sending messages to the server.
 *
 * @author Vinoth Kumar D
 * @version 0.5
 */
public class SimpleServer {

    /**
     * The main method is the entry point of the program.
     * It listens for incoming connections, receives messages, and prints
     * them to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            // Create a server socket on port 3414
            ServerSocket serverSocket = new ServerSocket(3414);

            System.out.println("Server started and waiting for connections...");

            // Wait for a client to establish a connection
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());

            // Create input and output streams for the client connection
            BufferedReader inputReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter outputWriter = new PrintWriter(clientSocket.getOutputStream(), true);

            String clientMessage;
            while ((clientMessage = inputReader.readLine()) != null) {
                System.out.println("Client says: " + clientMessage);
                if (clientMessage.equals("exit")) {
                    break;
                }

                // Process the message or generate a response
                String serverResponse = "Hello Client";
                outputWriter.println(serverResponse);
            }

            // Close the streams and sockets
            inputReader.close();
            outputWriter.close();
            clientSocket.close();
            serverSocket.close();

            System.out.println("Server closed.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
