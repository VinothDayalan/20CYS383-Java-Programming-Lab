package com.amrita.jpl.cys21086.p2;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

/**
 * @author Vinoth Kumar D
 * @params args
 * @return void
 * @description This program is to implement the Quiz Game
 * package com.amrita.jpl.cys21086.p2;
 */
abstract class QuizGame{
    //    private
    /**
     * @params scanner is used to get the input from the user
     * @return void
     * @description This method is used to get the input from the user
     */
    Scanner scanner = new Scanner(System.in);
    /**
     * @params question is used to store the question
     * @return void
     * @description This method is used to store the question
     */
    abstract void askQuestion();
    abstract void evaluateAnswer(String answer);

    abstract void startGame();

    public abstract void onQuestionAsked(String question);

    public abstract void onAnswerEvaluated(boolean isCorrect);
}
/**
 * @params listener is used to store the listener
 * @return void
 * @description This method is used to store the listener
 */
interface QuizGameListener{
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}
/**
 * @description QuizGameServer is used to store the question and answer
 * @return void
 */
class QuizGameServer extends QuizGame{
    QuizGameListener listener;
    String question;
    private String Corresctanswer;
    public void setListener(QuizGameListener listener) {
        this.listener = listener;
    }
    @Override
    void startGame() {
        askQuestion();
    }

    @Override
    public void onQuestionAsked(String question) {

    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {

    }

    @Override
    void askQuestion() {
        Random random = new Random();
        int randomNumber = random.nextInt(6);
        String[] questions = {"1+1", "2+1", "1+2","10-4","1+4","1+0", "0+0", "0+5"};
        String[] Answers = {"2","3","3","6","5","1","0","5"};
        int randomNumber1 = randomNumber;
//        question = "what is your name?";
        question = questions[randomNumber1];
        Corresctanswer = Answers[randomNumber1];
        listener.onQuestionAsked(question);
    }

    @Override
    void evaluateAnswer(String answer) {
        boolean isCorrect;
        if (answer.equalsIgnoreCase(Corresctanswer)) {
            isCorrect = true;
        } else {
            isCorrect = false;
        }
        listener.onAnswerEvaluated(isCorrect);
    }
}
/**
 * @params scanner is used to get the input from the user
 * @return void
 * @description This method is used to get the input from the user as client
 */
class QuizGameClient extends QuizGame implements QuizGameListener{
    private QuizGameServer server;
    Scanner scanner;
    public QuizGameClient() {
        scanner = new Scanner(System.in);
    }

    @Override
    void askQuestion() {

    }

    @Override
    void evaluateAnswer(String answer) {

    }

    @Override
    void startGame() {
        server = new QuizGameServer();
        server.setListener(this);
        server.startGame();
    }


    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);
        String answer = scanner.nextLine();
        server.evaluateAnswer(answer);
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Cient won -> Your answer is correct!");
        } else {
            System.out.println("Client lost -> Your answer is incorrect!");
        }
    }
}

class QuizGameClientRunnable implements Runnable {
    private QuizGameClient client;

    public QuizGameClientRunnable() {
        client = new QuizGameClient();
    }

    @Override
    public void run() {
        client.startGame();
    }
}

public class Main {

    public static void main(String[] args) {
//        QuizGameClient client = new QuizGameClient();
//        client.startGame();
        int numClients = 2; // Number of clients you want to support

        for (int i = 0; i < numClients; i++) {
            QuizGameClientRunnable clientRunnable = new QuizGameClientRunnable();
            Thread thread = new Thread(clientRunnable);
            thread.start();
        }
    }
}
