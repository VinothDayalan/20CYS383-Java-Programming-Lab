package com.amrita.jpl.cys21086.pract.gui;

import javax.swing.*;
import java.awt.*;

public class Interface extends JFrame {
    public Interface() {
        setTitle("NFT osint");
        setSize(800, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel label1 = new JLabel(" Link");
        JTextField link = new JTextField();
        JButton submit = new JButton("search");
        link.setPreferredSize(new Dimension(200, 30));
        add(label1);
        add(link);
        add(submit);
        setVisible(true);
    }
    public static void main(String[] args) {new Interface();}
}
