package com.amrita.jpl.cys21086.pract;

import java.io.*;

abstract class FileTransfer {
    abstract void saveFile(byte[] fileData, String filename);

    public abstract void connect(String ipAddress);

    void sendFile(String filename) {
        // Implementation for sending file to the server
        System.out.println("Sending file: " + filename);
    }
}

interface FileTransferListene {
    void onFileSent(String filename);
    void onFileSaved(String filename);
}

class FileTransferClient extends FileTransfer implements FileTransferListene {
    private FileTransferServe server;

    void setServer(FileTransferServe server) {
        this.server = server;
    }

    @Override
    public void connect(String ipAddress) {
        // Implementation for connecting to the server
    }

    @Override
    public void sendFile(String filename) {
        super.sendFile(filename);

        try {
            File file = new File(filename);
            if (file.exists()) {
                FileInputStream fileInputStream = new FileInputStream(file);
                byte[] fileData = new byte[(int) file.length()];
                fileInputStream.read(fileData);
                fileInputStream.close();

                server.saveFile(fileData, filename);
            } else {
                System.out.println("File does not exist.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void saveFile(byte[] fileData, String filename) {
        // Implementation for saving the file on the client side
        System.out.println("Saving file on the client side: " + filename);
    }

    @Override
    public void onFileSent(String filename) {
        System.out.println("File sent to the server: " + filename);
    }

    @Override
    public void onFileSaved(String filename) {
        System.out.println("File saved on the client side: " + filename);
    }
}

class FileTransferServe extends FileTransfer implements FileTransferListene {
    private FileTransferClient client;

    void setClient(FileTransferClient client) {
        this.client = client;
    }

    void start() {
        // Implementation for starting the server and listening for incoming file transfers
        System.out.println("Server started");
    }

    @Override
    void saveFile(byte[] fileData, String filename) {
        // Implementation for saving file on the server side
        System.out.println("Saving file on the server side: " + filename);
        client.onFileSaved(filename);
    }

    @Override
    public void connect(String ipAddress) {

    }

    @Override
    public void onFileSent(String filename) {
        System.out.println("File received by the server: " + filename);
    }

    @Override
    public void onFileSaved(String filename) {
        System.out.println("File saved on the server side: " + filename);
    }
}

public class MainFile {
    public static void main(String[] args) {
        FileTransferServe server = new FileTransferServe();
        FileTransferClient client = new FileTransferClient();

        server.setClient(client);
        client.setServer(server);

        server.start();

        // Sending a file from the client to the server
        String filename = "src/com/amrita/jpl/cys21086/ex/file.txt";
        client.sendFile(filename);
    }
}
