package com.amrita.jpl.cys21086.pract;
/**
 * @author Vinoth Kumar D
 * @version 0.5
 */

public class HelloWorld {
    /**
     * Main method that prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
