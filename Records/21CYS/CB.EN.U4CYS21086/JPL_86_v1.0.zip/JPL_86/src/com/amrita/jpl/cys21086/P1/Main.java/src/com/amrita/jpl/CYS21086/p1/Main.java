package com.amrita.jpl.CYS21086.p1;
import java.util.Scanner;

/**
 * @author cb.en.u4cys21086 VinothDayalan
 */

/**
 * This class is used to perform the following operations
 * 1. Factorial (fact)
 * 2. Fibonacci (fibo)
 * 3. The sum of ’n’ numbers (sum n no)
 * 4. Prime Test (prime test)
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
         * @param choice is used to select the operation
         */
        System.out.println("1. Factorial (fact)\n2. Fibonacci (fibo)\n3. The sum of 'n' numbers (sum n no)\n4. Prime Test (prime test)");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        /**
         * @param sumInt is used to store the input for factorial
         * @param fibInt is used to store the input for fibonacci
         * @param sumOfInt is used to store the input for sum of n numbers
         * @param primeInt is used to store the input for prime test
         */
        switch (choice) {
            case 1:
                System.out.print("Enter a positive integer: ");
                int sumInt = scanner.nextInt();
                System.out.printf("%d",fact(sumInt));
                break;
            case 2:
                System.out.print("Enter a positive integer: ");
                int fibInt = scanner.nextInt();
                fibo(fibInt);
                break;
            case 3:
                System.out.print("Enter a positive integer: ");
                int sumOfInt = scanner.nextInt();
                System.out.printf("%d",Sum(sumOfInt));
                break;
            case 4:
                System.out.print("Enter a positive integer: ");
                int primeInt = scanner.nextInt();
                if(primeInt>=0) {
                    if (prime_test(primeInt)) {
                        System.out.println(primeInt + " is a prime number.");
                    } else {
                        System.out.println(primeInt + " is not a prime number.");
                    }
                }else{
                    System.out.println("Please enter a Positive number!!!");
                }
                break;
            default:
                System.out.println("Enter the correct choice");
                break;
        }
    }
    /**
     * @param n is used to store the input for factorial
     * @return sum
     */
    // fact function is used to find the factorial of a given number
    public static int fact(int n){
        if (n>0) {
            int sum = 1;
            for (int i = 1; i < (n + 1); i++) {
                sum = (sum * i);
            }
            return sum;
        }else if(n==0){
            System.out.println("The given number is 0 so the factorial is also");
        }else{
            System.out.println("The given number is negative");
        }

        return n;
    }
    /**
     * @param n is used to store the input for fibonacci
     */
    // fibo function is used to find the fibonacci series of a given number
    public static void fibo(int n){
        if(n>2) {
            int a = 0, b = 1, temp = 0;
            System.out.printf("%d %d ", a, b);
            for (int i = 0; i < n; i++) {
                temp = a + b;
                a = b;
                b = temp;
                System.out.printf("%d ", temp);
            }
        } else if (n==0) {
            System.out.println(n);
        } else if (n==1) {
            System.out.printf("%d %d",0,1);
        } else{
            System.out.println("The given number is negative");
        }

    }
    /**
     * @param n is used to store the input for sum of n numbers
     * @return sum
     */
    // sum function is used to find the sum of n numbers
    public static int Sum(int n){
        if (n > 0) {
            int sum=0;
            for(int i=1;i<n+1;i++){
                sum = sum + i;
            }
            return sum;
        }else if(n==0){
            System.out.println("The given number is 0 so the sum is also ");
        }else{
            System.out.println("The given number is negative");
        }

        return n;
    }
    /**
     * @param n is used to store the input for prime test
     * @return true or false
     */
    // prime_test function is used to find the given number is prime or not
    public static boolean prime_test(int n){
        if (n < 2) {
            return false;
        } else if (n == 2) {
            return true;
        } else if (n % 2 == 0) {
            return false;
        } else {
            for (int i = 3; i <= Math.sqrt(n); i += 2) {
                if (n % i == 0) {
                    return false;
                }
            }
            return true;
        }
    }
}