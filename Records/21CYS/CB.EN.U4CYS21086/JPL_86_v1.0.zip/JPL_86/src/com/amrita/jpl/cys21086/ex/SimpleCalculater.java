package com.amrita.jpl.cys21086.ex;
import java.util.Scanner;

/**
 * This class is used to perform basic arithmetic operations.
 * It implements the Calculator interface.
 * It has a main method that takes two numbers as input and
 * performs the following operations:
 * 1. Addition
 * 2. Subtraction
 * 3. Multiplication
 * 4. Division
 * @author Vinoth Kumar D
 * @version 1.0
 */
public class SimpleCalculater {
    /**
     * @param num1 First number
     * @param num2 Second number
     * @return Sum of num1 and num2
     */
    interface Calculator {
        double add(double num1, double num2);
        double subtract(double num1, double num2);
        double multiply(double num1, double num2);
        double divide(double num1, double num2) throws ArithmeticException;
    }
    // Implement the Calculator interface
    static class BasicCalculator implements Calculator {
        // Implement the interface methods
        @Override
        // Add two numbers
        public double add(double num1, double num2) {
            return num1 + num2;
        }

        @Override
        // Subtract two numbers
        public double subtract(double num1, double num2) {
            return num1 - num2;
        }

        @Override
        // Multiply two numbers
        public double multiply(double num1, double num2) {
            return num1 * num2;
        }

        @Override
        // Divide two numbers
        public double divide(double num1, double num2) throws ArithmeticException {
            if (num2 == 0) {
                throw new ArithmeticException("Division by zero is not allowed.");
            }
            return num1 / num2;
        }
    }
/**
 * This is the main method which makes use of add, subtract, multiply and divide methods.
 * @param args
 */

    public static void main(String[] args) {
        // Create an object of BasicCalculator
        BasicCalculator calculator = new BasicCalculator();
        double num1, num2;

        // Scanner
        Scanner myObj = new Scanner(System.in);
        num1 = myObj.nextDouble();
        num2 = myObj.nextDouble();


        // Perform operations using BasicCalculator
        double sum = calculator.add(num1, num2);
        double difference = calculator.subtract(num1, num2);
        double product = calculator.multiply(num1, num2);
        double quotient;
        System.out.println("Addition: " + sum);
        System.out.println("Subtraction: " + difference);
        System.out.println("Multiplication: " + product);
        try {
            quotient = calculator.divide(num1, num2);
            System.out.println("Division: " + quotient);
        } catch (ArithmeticException e) {
            System.out.println("Division by zero error!");
            System.out.println("Division: -1.0");
        }

    }
}