package com.amrita.jpl.cys21086.ex;

/**
 * @author Vinoth Kumar D
 * @version 1.0
 */

class Vehicle {
    // private String modelName;
    private boolean run_status;
    public void start() {
        run_status = true;
        System.out.println("[Vehicle] started.");
    }
    public void stop() {
        run_status = false;
        System.out.println("[Vehicle] stopped.");
    }
    public boolean isRunning() {
        return run_status;
    }
}

/**
 * Car class extends Vehicle class
 * @see Vehicle
 * @param modelName - Name of the car
 * @param year - Year of manufacture
 * @param numOfWheels - Number of wheels
 * @return void
 * @exception IllegalStateException - If the car is not running
 */
class Car extends Vehicle {
    // private String modelName;
    private String modelName;
    private int year;
    private int numOfWheels;
    public Car(String modelName, int year, int numOfWheels) {
        this.modelName = modelName;
        this.year = year;
        this.numOfWheels = numOfWheels;
    }
    public String getModelName() {
        return modelName;
    }
    public int getYear() {
        return year;
    }
    public int getNumOfWheels() {
        return numOfWheels;
    }
    public void drive(int gearPosition) {
        if (isRunning()) {
            System.out.println("Driving the car in gear position: " + gearPosition);
        }
    }
}
/**
 * Bike class extends Vehicle class
 * @see Vehicle
 * @param brandName - Name of the bike
 * @param year - Year of manufacture
 * @param numOfGears - Number of gears
 * @return void
 * @exception IllegalStateException - If the bike is not running
 */

class Bike extends Vehicle {
    private String brandName;
    private int year;
    private int numOfGears;
    public Bike(String brandName, int year, int numOfGears) {
        this.brandName = brandName;
        this.year = year;
        this.numOfGears = numOfGears;
    }
    public String getBrandName() {
        return brandName;
    }
    public int getYear() {
        return year;
    }
    public int getNumOfGears() {
        return numOfGears;
    }
    public void pedal(int pedalSpeed) {
        if (isRunning()) {
            System.out.println("Pedaling the bike at speed: " + pedalSpeed);
        }
    }

}
/**
 * Vehicleinheritance2 class
 * @see Car
 * @see Bike
 * @param args - Command line arguments
 * @return void
 */
public class Vehicleinheritance2 {
    public static void main(String[] args) {
        Car car = new Car("Jaguar XF", 2022, 4);
        System.out.println("Car Instantiated with Parameters: " + car.getModelName() + ", " + car.getYear() + ", " + car.getNumOfWheels());

        try {
            car.drive(3);
        } catch (IllegalStateException e) {
            System.out.println("Cannot drive. Start the car first.");
        }

        car.stop();
        System.out.println(car);

        Bike bike = new Bike("Giant", 2021, 18);
        System.out.println("Bike Instantiated with Parameters: " + bike.getBrandName() + ", " + bike.getYear() + ", " + bike.getNumOfGears());

        try {
            bike.pedal(15);
        } catch (IllegalStateException e) {
            System.out.println("Cannot pedal. Start the bike first.");
        }

        bike.stop();
        System.out.println(bike);
    }
}