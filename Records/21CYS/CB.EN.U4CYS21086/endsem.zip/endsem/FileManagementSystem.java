package com.amrita.jpl.cys21086.endSem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

abstract class File {
    private String fileName;
    private long fileSize;

    public String getFileName() {
        return fileName;
    }
    public long getFileSize() {
        return fileSize;
    }
    public void displayFileDetails() {
        System.out.println("File Name: " + fileName);
        System.out.println("File Size: " + fileSize);
    }
    public File(String fileName, int fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }
}

class Document extends File {
    private String documentType;

    public Document(String documentType, String fileName, long fileSize) {
        super(fileName, (int) fileSize);
        this.documentType= documentType;
    }
    public String getDocumentType() {
        return documentType;
    }
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }
}

class Image extends File {
    private String resolution;

    public Image(String resolution, String fileName, long fileSize) {
        super(fileName, (int) fileSize);
        this.resolution = resolution;
    }

    public String resolution() {
        return resolution;
    }
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Resolution: " + resolution);
    }
}

class Video extends File {
    private String duration;
    public Video(String duration, String fileName, long fileSize) {
        super(fileName, (int) fileSize);
        this.duration = duration;
    }
    public String duration() {
        return duration;
    }
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("duration: " + duration);
    }
}

interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void saveToFile(String fileName);

    void displayAllFiles();

    default void saveTheFile(String fileName){
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            outputStream.writeObject(fileName);
            System.out.println("File details saved to " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    };

}

class FileManagerImpl implements FileManager{

    private ArrayList<File> files;
    public FileManagerImpl() {
        files = new ArrayList<>();
    }


    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++){
            if (files.get(i).getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    @Override
    public void displayAllFiles() {
        for (File file : files) {
            file.displayFileDetails();
            System.out.println();
        }
    }


    public void saveToFile(String fileName) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            outputStream.writeObject(files);
            System.out.println("File details saved to " + fileName);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFileDetails(String fileName) {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            files = (ArrayList<File>) inputStream.readObject();
            System.out.println("File details loaded from " + fileName);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

class FileManagementSystemUI extends JFrame implements ActionListener{
    private FileManager fileManager;
    private JTextField fileNameField, fileSizeField, fileTypeField, resolutionField, durationField;
    private JButton addDocumentButton, addImageButton, addVideoButton, deleteButton, displayButton,
            saveButton, loadButton;
    private JTable fileTable;
    private DefaultTableModel tableModel;

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addDocumentButton) {
            String fileName = fileNameField.getText();
            long fileSize = Long.parseLong(fileSizeField.getText());
            String documentType = fileTypeField.getText();
            Document document = new Document(documentType, fileName, fileSize);
            fileManager.addFile(document);
            addToTable(document);
        } else if (e.getSource() == addImageButton) {
            String fileName = fileNameField.getText();
            long fileSize = Long.parseLong(fileSizeField.getText());
            String resolution = fileTypeField.getText();
            Image image = new Image(resolution, fileName, fileSize);
            fileManager.addFile(image);
            addToTable(image);
        } else if (e.getSource() == addVideoButton) {
            String fileName = fileNameField.getText();
            long fileSize = Long.parseLong(fileSizeField.getText());
            String duration = fileTypeField.getText();
            Video video = new Video(duration, fileName, fileSize);
            fileManager.addFile(video);
            addToTable(video);
        } else if (e.getSource() == deleteButton) {
            int selectedRow = fileTable.getSelectedRow();
            if (selectedRow != -1) {
                String fileName = tableModel.getValueAt(selectedRow, 0).toString();
                fileManager.deleteFile(fileName);
                tableModel.removeRow(selectedRow);
            }
        } else if (e.getSource() == displayButton) {
            tableModel.setRowCount(0);
            fileManager.displayAllFiles();
        } else if (e.getSource() == saveButton) {
            String fileName = JOptionPane.showInputDialog("Enter document type:");
            fileManager.saveToFile(fileName);
        }
    }


    private void addToTable(File FileType) {
        Object[] rowData = new Object[3];
        rowData[0] = FileType.getFileName();
        rowData[1] = FileType.getFileSize();

        if (FileType instanceof Document) {
            rowData[2] = "Document";
        } else if (FileType instanceof Image) {
            rowData[2] = "Image";
        } else if (FileType instanceof Video) {
            rowData[2] = "Video";
        }

        tableModel.addRow(rowData);
    }

    public FileManagementSystemUI() {
        JComboBox<String> typeComboBox;
        setTitle("21UCYS End Semester Assignment File Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 300);
        setLayout(new FlowLayout());

        JPanel fileInputDiv = new JPanel();
        fileInputDiv.setLayout(new FlowLayout());
        JLabel fileNameLabel = new JLabel("File Name:");
        JTextField fileNameField = new JTextField(10);
        JLabel fileSizeLabel = new JLabel("File Size:");
        JTextField fileSizeField = new JTextField(10);
        JLabel fileTypeLabel = new JLabel("File Type:");
        String[] types = { "Document","Image","Video" };
        typeComboBox = new JComboBox<>(types);

        fileInputDiv.add(fileNameLabel);
        fileInputDiv.add(fileNameField);
        fileInputDiv.add(fileSizeLabel);
        fileInputDiv.add(fileSizeField);
        fileInputDiv.add(fileTypeLabel);
        fileInputDiv.add(typeComboBox);
        add(fileInputDiv);
        setVisible(true);

        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("Type");

        fileTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(fileTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(this);

        displayButton = new JButton("Refresh");
        displayButton.addActionListener(this);

        saveButton = new JButton("Add File");
        saveButton.addActionListener(this);

        buttonPanel.add(saveButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(displayButton);
        add(buttonPanel);
    }
}

public class FileManagementSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}